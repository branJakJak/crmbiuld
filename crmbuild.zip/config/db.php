<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=crmbuild',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
